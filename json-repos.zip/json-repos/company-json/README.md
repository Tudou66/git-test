#json文件控制流程描述

### **逻辑整理**
- 1.以json文件为根本（公司+车辆类型），json文件根据protocol.xml和system.xml生成；
- 2.各个json文件以及其中的各种内容根据两个xml中的标记生成；
- 3.json文件+t_company_setting 设置系统的分类显示,系统显示的改动保存在t_company_setting中；
- 4.json文件与t_company_setting以json文件中为主，json文件中没有的系统，无论t_company_setting表中有或没有都不显示；
- 5.json文件+t_user_setting_order 设置用户开关量，开关量的改动保存在t_user_setting_order表中；
- 6.json文件与t_user_setting_order以json文件为主，json文件中没有的开关量，无论t_user_setting_order中是否存在都不显示。


### **json文件生成逻辑整理**
- 1.system.xml中保存有各公司的大小系统关系；
- 2.若要增加或去掉某个公司json文件中指定系统内容，需要增加或删除system.xml中指定系统下的该公司的标记；
- 3.protocol.xml中保存有各个公司各个车辆类型包含的数据量（模拟量，状态量，报警量）；
- 4.若要增加或去掉某个公司json文件中指定数据量，需要增加或删除protocol.xml中的指定数据量下的该公司的标记。


### **关联整理**
- t_company_setting：根据总公司存储所属的小系统；
- t_user_setting_order: 存储开关量；
- 通过修改t_company_setting可改变系统分类的显示；
- 通过修改t_user_setting_order可改变数据量的显示；


### **协议量发生变化**
- protocol.xml需要改动；
- json文件需要重新生成；
- t_user_setting_order表中需要对应改动。


### **系统分类发生变化**
- system.xml需要改动；
- json文件需要重新生成；
- t_company_setting中需要对应改动。


### **开关量显示逻辑**
- 1.根据公司标识查询t_user_setting_order表中对应的开关量设置，a
- 2.根据公司标识获取对应的大小系统及量的json文件，b
- 3.根据公司标识查询t_company_setting获取该公司所包含的子系统，c
- 4.循环b，判断json文件中的小系统c中是否存在；存在则返回结果中标记为显示，不存在标记为不显示，
- 5.循环a中的小系统的状态量，判断b 中json文件小系统量是否包含，包含则将a中该量的状态信息并入返回结果集合，否则不处理；


### **系统分类显示逻辑**
- 传入车辆相关标识（id，车牌号），则根据车辆的协议类型所属json文件显示；
- 传入机构相关标识（id，名称），则根据机构的协议类型所属json文件显示；
- 无参数传入，则根据登录系统的账号所属机构进行显示；
- 无参数传入，管理员账号，默认显示dongguan协议内容。














